<?php

/*define ('host','localhost');
define ('user','root');
define('password','');

define ('practice', 'a1');

$db_connection=mysql_connect(HOST,USER,PASSWORD,PRACTICE);
if ($db_connection)
echo "conecction succsfull";
else  
echo "ERROR";
-->
*/
define ('host','localhost');
define ('user','root');
define('password','');

define ('dbname', 'PRACTICE');

// $SERVER_NAME="localhost";
// $USERNAME="username";
// $PASSWORD="password";
// $DBNAME="mydb";

//$conn = new mysqli($SERVER_NAME,$USERNAME,$PASSWORD,$DBNAME);
$conn=mysqli_connect(host,user,password,dbname);
if($conn->connect_error)
{
    die("connection failed:".$conn->connect_error);
}
 $sql= "INSERT INTO STUDENTS VALUES(1,'ALI',3.9,'L1F20BSSE0008')";
 
 if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();

?>